import Routing from '../src/components/routes';
import './App.css';

function App() {
  return (
    
    <div className="App">
      <Routing />
    </div>
  );
}

export default App;
