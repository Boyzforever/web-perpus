import React, { useState,useEffect } from 'react';
import { Table, Space, Button, Image, Form, Input, message } from 'antd';
import axios from 'axios';
import Sider from 'antd/es/layout/Sider';
import EditBookForm from './editBuku';
const { TextArea } = Input;

export const BukuAdmin = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [dataSource, setDataSource] = useState([]);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editedData, setEditedData] = useState({});
  const[gambar , setGambar] = useState(null);
  const handleEditClick = (data) => {
    console.log('edit data',data)
    setEditedData(data);
    setEditModalVisible(true);
  };
  const handleFileChange = (event) => {
    if (event.target.files && event.target.files.length > 0) {
      const selectedFile = event.target.files[0];
      setGambar(selectedFile);
    }
  };
  const handleEditCancel = () => {
    setEditModalVisible(false);
  };
  
  const handleEditSave = (updatedData,id) => {
    // Lakukan sesuatu dengan data yang telah diperbarui
    console.log('Data yang diperbarui:' +  updatedData + 'dengan id ' + id);
    setEditModalVisible(false);
    editBuku(updatedData,id)
  };
  

  const getBuku = async () =>{
    try{
      const response = await axios.get('http://127.0.0.1:8090/api/collections/Buku/records')
      console.log(response)
      setDataSource(response.data.items)
    } catch(error){
      console.error(error);
    }
  }
  useEffect(()=>{
    getBuku()
  },[])
  const editBuku = async (values,id)=>{
    try{
        const response = await axios.patch(`http://127.0.0.1:8090/api/collections/Buku/records/${id}`,
    values,{ headers :{
        "Content-Type" : "application/json"
    }})
       console.log(response) 
    }catch(e){
        console.error(e)
    }finally{getBuku()}
  }
  const deleteBuku = async (id) =>{
    try{
        const response = await axios.delete(`http://127.0.0.1:8090/api/collections/Buku/records/${id}`)
        console.log(response)
    }catch(e){
        console.error(e)
    }finally{getBuku()}
  }


  const columns = [
    {
      title: 'Judul Buku',
      dataIndex: 'judul',
      key: 'judul',
    },
    {
      title: 'Penulis',
      dataIndex: 'penulis',
      key: 'penulis',
    },
    {
      title: 'Penerbit',
      dataIndex: 'penerbit',
      key: 'penerbit',
    },
    {
      title: 'Tahun Terbit',
      dataIndex: 'tahun_terbit',
      key: 'tahun_terbit',
    },
    {
      title: 'Foto',
      dataIndex: 'id',
      key: 'Foto',
      render: (record) => {
        const fotoUrl = `http://127.0.0.1:8090/Api/files/${record.collectionId}/${record.id}/${record.foto}`;
        console.log('Foto URL:', fotoUrl); // Tambahkan console.log disini
        return <img src={fotoUrl} alt="Book Cover" style={{ width: '50px', height: 'auto' }} />;
      },
    },
    {
        title:'aksi',
        render: (record) =>(
        <Space>
            <Button type='primary ' onClick={() => handleEditClick(record)}>
                Edit
            </Button>
            <Button type='primary'onClick={()=>deleteBuku(record.id)}>
                Delete
            </Button>
        </Space>
        )
    }

  ];

  const handleOk = () => {
    setIsModalVisible(false);
    message.success('Buku telah berhasil dipinjam');
    // Tambahkan logika untuk mengupdate status ketersediaan buku di database
  };

  // const handleCancel = () => {
  //   setIsModalVisible(false);
  // };

  // const showModal = () => {
  //   setIsModalVisible(true);
  // };


  const onFinish = async (values) => {
    const formData = new FormData();
    formData.append("judul", values.judul);
    formData.append("tahun_terbit", values.tahun_terbit);
    formData.append("penerbit", values.penerbit);
    formData.append("penulis", values.penulis);
    formData.append("Foto", gambar);

    try {
      const response = await axios.post('http://127.0.0.1:8090/api/collections/Buku/records', formData, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      });
      console.log(response.data);
      message.success('Buku telah berhasil ditambahkan');
      setIsModalVisible(false);
      getBuku();
    } catch (error) {
      console.error(error);
      message.error('Gagal menambahkan buku');
    }
  };
  return (
    <div>
      <Table
        dataSource={dataSource}
        columns={columns}
        pagination={false}
      />
        <Form
          name="basic"
          layout='vertical'
          onFinish={onFinish}
        >
          <Form.Item
            label="judul Buku"
            name="judul"
            rules={[{ required: true, message: 'Please input your name!' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Penulis"
            name="penulis"
            rules={[{ required: true, message: 'Please input borrow date!' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Penerbit"
            name="penerbit"
            rules={[{ required: true, message: 'Please input return date!' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Tahun terbit"
            name="tahun_terbit"
          >
            <Input />
          </Form.Item>
          <Form.Item
          label="Foto Buku"
          name="Foto"
        >
          <input type='file'
            accept='.jpg,.jpeg,.png'
            onChange={handleFileChange}
          />
        </Form.Item>


          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
        <EditBookForm
        visible={editModalVisible}
        onCancel={handleEditCancel}
        onSave={handleEditSave}
        initialData={editedData}
      />
    </div>
  );
};

