import React, { useEffect, useState } from 'react';
import { Table, Space, Button, Modal, Form, Input, message } from 'antd';
const { TextArea } = Input;

const BookTable = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [dataSource, setDataSource] = useState([]);
  const columns = [
    {
      title: 'Judul Buku',
      dataIndex: 'title',
      key: 'title',
    },
    {
      title: 'Penulis',
      dataIndex: 'author',
      key: 'author',
    },
    {
      title: 'Penerbit',
      dataIndex: 'publisher',
      key: 'publisher',
    },
    {
      title: 'Tahun Terbit',
      dataIndex: 'publicationYear',
      key: 'publicationYear',
    },
    {
      title: 'Nomor ISBN',
      dataIndex: 'isbn',
      key: 'isbn',
    },
    {
      title: 'Deskripsi',
      dataIndex: 'description',
      key: 'description',
    },
    {
      title: 'Status Ketersediaan',
      dataIndex: 'availability',
      key: 'availability',
    },
    {
      title: 'Ulasan',
      dataIndex: 'review',
      key: 'review',
    },
    {
      title: 'Tindakan Peminjaman',
      key: 'action',
      render: () => (
        <Space size="middle">
          <Button type="primary" onClick={showModal}>
            Pinjam
          </Button>
        </Space>
      ),
    },
    {
      title: 'Lokasi Fisik',
      dataIndex: 'physicalLocation',
      key: 'physicalLocation',
    },
  ];

  const handleOk = () => {
    setIsModalVisible(false);
    message.success('Buku telah berhasil dipinjam');
    // Tambahkan logika untuk mengupdate status ketersediaan buku di database
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const showModal = () => {
    setIsModalVisible(true);
  };

  const onFinish = (values) => {
    console.log('Received values:', values);
    // Lakukan sesuatu dengan data peminjaman
    handleOk();
  };

  return (
    <div>
      <Table
        dataSource={dataSource}
        columns={columns}
        pagination={false}
      />
      <Modal title="Form Peminjaman Buku" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel}>
        <Form
          name="basic"
          onFinish={onFinish}
        >
          <Form.Item
            label="Nama Peminjam"
            name="borrowerName"
            rules={[{ required: true, message: 'Please input your name!' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Tanggal Peminjaman"
            name="borrowDate"
            rules={[{ required: true, message: 'Please input borrow date!' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Tanggal Pengembalian"
            name="returnDate"
            rules={[{ required: true, message: 'Please input return date!' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Catatan Peminjaman"
            name="borrowNotes"
          >
            <TextArea />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default BookTable;
