import React, { useState } from 'react';
import { Form, Input, Button, DatePicker, message } from 'antd';

const BorrowBookForm = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const onFinish = (values) => {
    setLoading(true);
    // Kirim data peminjaman buku ke server atau lakukan operasi lainnya
    setTimeout(() => {
      setLoading(false);
      message.success('Buku berhasil dipinjam!');
      form.resetFields();
    }, 2000);
  };

  return (
    <Form
      form={form}
      layout="vertical"
      onFinish={onFinish}
    >
      <Form.Item
        label="Nomor Identitas Peminjam"
        name="userId"
        rules={[{ required: true, message: 'Masukkan nomor identitas peminjam!' }]}
      >
        <Input />
      </Form.Item>

      <Form.Item
        label="Tanggal Peminjaman"
        name="borrowDate"
        rules={[{ required: true, message: 'Pilih tanggal peminjaman!' }]}
      >
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>

      <Form.Item
        label="Tanggal Pengembalian"
        name="returnDate"
        rules={[{ required: true, message: 'Pilih tanggal pengembalian!' }]}
      >
        <DatePicker.RangePicker style={{ width: '100%' }} />
      </Form.Item>

      <Form.Item>
        <Button type="primary" htmlType="submit" loading={loading}>
          Pinjam Buku
        </Button>
      </Form.Item>
    </Form>
  );
};

export default BorrowBookForm;
