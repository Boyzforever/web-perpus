import React, { useState } from 'react';
import { Modal, Button, Form, Input } from 'antd';

const EditBookForm = ({ visible, onCancel, onSave, initialData }) => {
  const [form] = Form.useForm();
  const [formData, setFormData] = useState(initialData);
  const [gambar , setGambar] = useState ();
  const handleSave = () => {

    const data = {
        judul:formData.judul?formData.judul:initialData.judul,
        penulis:formData.penulis?formData.penulis:initialData.penulis,
        penerbit:formData.penerbit?formData.penerbit:initialData.penerbit,
        tahun_terbit:formData.tahun_terbit?formData.tahun_terbit:initialData.tahun_terbit
    }
    onSave(data, initialData.id)
  };
  const handleFileChange = (event) => {
    if (event.target.files && event.target.files.length > 0) {
      const selectedFile = event.target.files[0];
      setGambar(selectedFile);
    }
  };


  const handleChange = (changedValues, allValues) => {
    setFormData({ ...formData, ...allValues });
  };

  return (
    <Modal
      visible={visible}
      title="Edit Buku"
      onCancel={onCancel}
      footer={[
        <Button key="cancel" onClick={onCancel}>
          Batal
        </Button>,
        <Button key="save" type="primary" onClick={handleSave}>
          Simpan
        </Button>,
      ]}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={formData}
        onValuesChange={handleChange}
      >
        <Form.Item
          name="judul"
          label="Judul Buku"
          
          rules={[{ required: true, message: 'Harap masukkan judul buku!' }]}
        >
          <Input initialValues={initialData.judul} defaultValue={initialData.judul}/>
        </Form.Item>
        <Form.Item
          name="penerbit"
          label="Penerbit"
          rules={[{ required: true, message: 'Harap masukkan penerbit!' }]}
        >
          <Input initialValues={initialData.penerbit} defaultValue={initialData.penerbit}/>
        </Form.Item>
        <Form.Item
          name="penulis"
          label="Penulis"
          rules={[{ required: true, message: 'Harap masukkan penulis!' }]}
        >
          <Input initialValues={initialData.penulis} defaultValue={initialData.penulis}/>
        </Form.Item>
        <Form.Item
          name="tahun_terbit"
          label="Tahun Terbit"
          rules={[{ required: true, message: 'Harap masukkan tahun terbit!' }]}
        >
          <Input initialValues={initialData.tahun_terbit} defaultValue={initialData.tahun_terbit}/>

        </Form.Item>
        <Form.Item
          label="Foto Buku"
          name="Foto"
        >
          <input type='file'
            accept='.jpg,.jpeg,.png'
            onChange={handleFileChange}
          />
                    <Input initialValues={initialData.Foto} defaultValue={initialData.Foto}/>

        </Form.Item>
      </Form>
    </Modal>
  );
};

export default EditBookForm;
