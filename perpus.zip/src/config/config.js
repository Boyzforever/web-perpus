const config = {
    apiUrl: 'http://127.0.0.1:8090/api', // URL endpoint API Pocketbase
  };
  
  export default config;
  